#!/usr/bin/perl
 
use Understand;
$db = Understand::open("MyUnderstandProject.udb");

open(DATA, ">data.csv") or die "data.txt 文件无法打开, $!";
print DATA "Name,CountLineCode,CountPath,Cyclomatic,MaxNesting,Knots,CountInput,CountOutput\n";

foreach $func ($db->ents("Function"))
{
	$value_Name 		 = $func->name();
    $value_CountLineCode = $func->metric("CountLineCode");
	$value_CountPath     = $func->metric("CountPath");
	$value_Cyclomatic    = $func->metric("Cyclomatic");
	$value_MaxNesting 	 = $func->metric("MaxNesting");
	$value_Knots 	 	 = $func->metric("Knots");
	$value_CountInput 	 = $func->metric("CountInput");
	$value_CountOutput   = $func->metric("CountOutput");
	print DATA $value_Name , ",",$value_CountLineCode,",",$value_CountPath,",", $value_Cyclomatic,",",$value_MaxNesting ,",",$value_Knots,",",$value_CountInput,",",$value_CountOutput ,"\n";
}

close(DATA);
